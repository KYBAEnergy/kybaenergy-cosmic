# KYBA Review SaaS System

This is the initial structure for the KYBA Review System — a decentralized review platform gated by token/NFT ownership. It includes:

- Phantom wallet connection
- Firebase backend (reviews storage)
- SPL token/NFT gating
- SaaS-ready folder structure for future embedding and monetization
