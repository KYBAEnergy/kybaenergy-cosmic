
document.getElementById("connect-wallet").addEventListener("click", async () => {
  try {
    const resp = await window.solana.connect();
    const address = resp.publicKey.toString();
    document.getElementById("wallet-address").innerText = "Connected wallet: " + address;
  } catch (err) {
    alert("Wallet connection failed.");
  }
});

document.getElementById("review-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const review = e.target.querySelector("textarea").value;
  const container = document.getElementById("reviews-container");
  const div = document.createElement("div");
  div.innerText = review;
  div.style.marginTop = "20px";
  div.style.padding = "10px";
  div.style.border = "1px solid #0ff";
  container.appendChild(div);
  e.target.reset();
});
