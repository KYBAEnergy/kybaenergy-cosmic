
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCEN...",
  authDomain: "kyba-review.firebaseapp.com",
  projectId: "kyba-review",
  storageBucket: "kyba-review.appspot.com",
  messagingSenderId: "1031079489278",
  appId: "1:1031079489278:web:b1d8b36b9ef54cd12bcfb4"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const walletBtn = document.getElementById('walletConnectBtn');
const walletStatus = document.getElementById('walletStatus');
let walletAddress = null;

async function connectWallet() {
  if (window.solana && window.solana.isPhantom) {
    try {
      const resp = await window.solana.connect();
      walletAddress = resp.publicKey.toString();
      walletStatus.textContent = `Connected: ${walletAddress.slice(0,6)}...${walletAddress.slice(-4)}`;
      walletBtn.textContent = 'Disconnect Wallet';
      loadReviews();
    } catch (err) {
      walletStatus.textContent = 'Connection rejected';
    }
  } else {
    walletStatus.textContent = 'Phantom wallet not found.';
  }
}

function disconnectWallet() {
  walletAddress = null;
  walletStatus.textContent = 'Not connected';
  walletBtn.textContent = 'Connect Wallet';
}

walletBtn.addEventListener('click', () => {
  if (walletAddress) {
    disconnectWallet();
  } else {
    connectWallet();
  }
});

const nftMintBtn = document.getElementById('nftMintBtn');
const mintStatus = document.getElementById('mintStatus');

nftMintBtn.addEventListener('click', () => {
  if (!walletAddress) {
    mintStatus.textContent = 'Connect wallet first!';
    mintStatus.style.color = 'tomato';
    return;
  }
  mintStatus.style.color = '#f2c94c';
  mintStatus.textContent = 'Minting your NFT... (simulated)';
  setTimeout(() => {
    mintStatus.textContent = 'NFT minted successfully! 🎉';
  }, 2000);
});

const reviewForm = document.getElementById('reviewForm');
const reviewInput = document.getElementById('reviewInput');
const reviewsList = document.getElementById('reviewsList');

async function loadReviews() {
  const querySnapshot = await getDocs(collection(db, "reviews"));
  reviewsList.innerHTML = '';
  querySnapshot.forEach((doc) => {
    const data = doc.data();
    const div = document.createElement('div');
    div.className = 'reviewItem';
    div.textContent = `${data.wallet}: "${data.text}"`;
    reviewsList.appendChild(div);
  });
  if (reviewsList.innerHTML === '') {
    reviewsList.innerHTML = '<i>No reviews yet. Be the first!</i>';
  }
}

reviewForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!walletAddress) {
    alert('Connect Phantom wallet first.');
    return;
  }
  const text = reviewInput.value.trim();
  if (text.length < 10) {
    alert('Review too short.');
    return;
  }
  await addDoc(collection(db, "reviews"), {
    wallet: walletAddress.slice(0,6) + '...' + walletAddress.slice(-4),
    text: text,
    timestamp: new Date()
  });
  reviewInput.value = '';
  loadReviews();
});
